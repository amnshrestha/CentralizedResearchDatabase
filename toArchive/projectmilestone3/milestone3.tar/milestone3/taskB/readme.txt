Task B

Source of data:
Ideally we would get the information from the university library. However, we haven’t yet been able to complete that part. Therefore, the data is populated by dummy values for now. 

The sql files in this directory are: create.sql and load.sql
To run the command, we used:
Mysql -u ashrest2 -p ashrest2_1<create.sql 
Mysql -u ashrest2 -p ashrest2_1<load.sql
And used our passwords.
